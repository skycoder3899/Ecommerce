package com.monk.commerce.cop.Exception;

public class InvalidCouponDetailsException extends RuntimeException {
    public InvalidCouponDetailsException(String message) {
        super(message);
    }
}
